#ifndef ASSIGNMENT1_SIGNAL_HANDLER_H
#define ASSIGNMENT1_SIGNAL_HANDLER_H

#include "process_handler.h"

void handle_signals();

#endif //ASSIGNMENT1_SIGNAL_HANDLER_H
